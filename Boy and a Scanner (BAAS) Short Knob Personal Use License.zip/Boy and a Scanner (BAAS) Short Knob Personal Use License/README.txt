SDS100 Glow Knob - 3D Print Instructions

PRINT SETTINGS:
- Material: PETG or PLA (glow-in-the-dark filament recommended)
- Layer height: 0.2mm
- Infill: 20%+
- Supports: None. Base may be needed if print bed has adhesion issues.

FIT NOTES:
Different Materials can fit different. Small scaling may be needed.

SUPPORT:
Questions? Email - contact@boyandascanner.com or YouTube @boyandascanner

LICENSE:
Personal use only. See LICENSE.txt for full terms.

Thanks for supporting Boy and a Scanner!
Tag @boyandascanner when you post your build! 

Cheers
